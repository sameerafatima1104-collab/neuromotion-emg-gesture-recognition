package com.example.neuromotion;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    // المعرفات الخاصة بالبلوتوث (يجب أن تطابق كود الـ ESP32)
    private static final String SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
    private static final String CHARACTERISTIC_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner bluetoothLeScanner;
    private BluetoothGatt bluetoothGatt;
    private boolean isScanning = false;
    private Handler handler = new Handler(Looper.getMainLooper());

    private TextView tvStatus, tvEmgValue, tvAction;
    private Button btnConnect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ربط العناصر بالواجهة
        tvStatus = findViewById(R.id.tvStatus);
        tvEmgValue = findViewById(R.id.tvEmgValue);
        tvAction = findViewById(R.id.tvAction);
        btnConnect = findViewById(R.id.btnConnect);

        BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();

        btnConnect.setOnClickListener(v -> {
            checkPermissions();
            startScan();
        });
    }

    private void checkPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, 1);
        }
    }

    private void startScan() {
        if (isScanning) return;
        isScanning = true;
        tvStatus.setText("Status: Searching for ESP32...");
        handler.postDelayed(() -> stopScan(), 10000); // يتوقف البحث بعد 10 ثواني
        bluetoothLeScanner.startScan(scanCallback);
    }

    private void stopScan() {
        isScanning = false;
        bluetoothLeScanner.stopScan(scanCallback);
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            BluetoothDevice device = result.getDevice();
            if ("NeuroMotion_BLE".equals(device.getName())) {
                stopScan();
                connectToDevice(device);
            }
        }
    };

    private void connectToDevice(BluetoothDevice device) {
        tvStatus.setText("Status: Connecting...");
        bluetoothGatt = device.connectGatt(this, false, gattCallback);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread(() -> tvStatus.setText("Status: Connected ✅"));
                gatt.discoverServices();
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread(() -> tvStatus.setText("Status: Disconnected ❌"));
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            BluetoothGattCharacteristic characteristic = gatt
                    .getService(UUID.fromString(SERVICE_UUID))
                    .getCharacteristic(UUID.fromString(CHARACTERISTIC_UUID));

            gatt.setCharacteristicNotification(characteristic, true);
            BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            gatt.writeDescriptor(descriptor);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            String value = new String(characteristic.getValue());
            runOnUiThread(() -> updateUI(value));
        }
    };

    private void updateUI(String value) {
        tvEmgValue.setText(value);
        int val = Integer.parseInt(value);

        // منطق تحديد الحركة (عكسي كما فعلنا في ESP32)
        if (val < 15) {
            tvAction.setText("FLEX DETECTED!");
            tvAction.setTextColor(android.graphics.Color.CYAN);
        } else {
            tvAction.setText("Relaxed");
            tvAction.setTextColor(android.graphics.Color.GRAY);
        }
    }
}